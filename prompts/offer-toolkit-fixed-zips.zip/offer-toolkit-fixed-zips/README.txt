Offer Toolkit by yanliudesign (MIT licence, see LICENSE): https://github.com/yanliudesign/offer-toolkit-skill
Repackaged for claude.ai, which takes one SKILL.md per zip: one zip per skill folder, made from commit 3b85d2e.
One change: in salary-negotiation-skill/SKILL.md the six straight double quotes inside the description became 「」 corner
quotes, because claude.ai rejected the original with "malformed YAML frontmatter in SKILL.md". Nothing else changed.
Install: claude.ai > Customize > Skills > Add > Upload skill, pick all six zips, Upload.
