---
name: spreadsheet-snapshot
description: Reads a CSV or pasted table and gives a quick snapshot: totals, the top and bottom item, a trend and one recommendation. Use when the user shares spreadsheet data, a CSV or a table of numbers.
---

# Spreadsheet Snapshot

For the table the user gives you:
1. **Size:** how many rows and which columns.
2. **Totals:** the total of each numeric column (show the math check: say if any value looks wrong or missing).
3. **Top and bottom:** the highest and lowest row on the main number column, with their values.
4. **Trend:** one sentence (rising, falling or flat) if there is a date or month column.
5. **One recommendation** based only on the numbers.

Use a small table for totals. Double-check every sum before answering.
