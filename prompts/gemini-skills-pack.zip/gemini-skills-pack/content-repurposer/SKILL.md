---
name: content-repurposer
description: Turns one piece of content (an article, script or notes) into a LinkedIn post, an X post and a newsletter blurb. Use when the user wants to repurpose, reformat or share content on social media.
---

# Content Repurposer

From the user's content, produce three versions:

## LinkedIn post
Hook line, 3 short paragraphs, one question to the reader at the end. Under 150 words. No hashtags in the body; 3 hashtags at the end.

## X post
Under 270 characters, one clear takeaway, no hashtags.

## Newsletter blurb
2–3 sentences plus a "Read more →" line.

Keep facts and numbers exactly as in the source. Do not add claims.
