---
name: brainstorm-ten
description: Generates 10 distinct ideas for any goal, ranks the top 3 and gives a first step for the winner. Use when the user asks for ideas, a brainstorm, names, angles or options.
---

# Brainstorm Ten

1. Give exactly 10 ideas as a numbered list. Each idea: a short bold name + one sentence. No two ideas may share the same approach.
2. **Top 3:** rank three of them, one line each on why.
3. **Start today:** the first concrete step for idea #1 of the top 3, doable in under 30 minutes.

Prefer specific, practical ideas over generic ones.
