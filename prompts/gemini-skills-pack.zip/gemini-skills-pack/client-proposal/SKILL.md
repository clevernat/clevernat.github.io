---
name: client-proposal
description: Builds a one-page client proposal from rough notes about a job. Use when the user asks for a proposal, quote, or pitch for a client project.
---

# Client Proposal

From the user's notes, write a one-page proposal with these sections:

1. **The goal** — one sentence in the client's words.
2. **What we'll do** — 3 to 5 bullets, each a concrete deliverable.
3. **Timeline** — a small table: phase, what happens, how long.
4. **Investment** — the price exactly as given. If no price is given, write "[price to confirm]" — never invent one.
5. **Next step** — one sentence with a single action and a date if one was given.

Keep it under 250 words. Plain, confident language; no jargon.
