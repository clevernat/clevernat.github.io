# Test notes from the video
Paste each into a new chat after attaching the skill (type / and its name). Write down what a correct answer must contain first.

## meeting-recap

```
notes from mktg sync tues - attendees Dana, Marco, Priya
- launch moved from 10/14 to 10/21, everyone agreed
- Marco owns the landing page, needs it by fri 10/17
- Priya to send the ad budget numbers, no date
- budget for influencers?? nobody knew, ask finance
- Dana will brief the agency on the new date by wed
- do we still do the webinar? undecided
```

Must contain: launch moved to 10/21; Marco | landing page | Fri 10/17; Priya | ad budget | No date; Dana | brief agency | Wed; influencer budget open; webinar open; Ready to paste into an email

## email-in-my-voice

```
Reply to this: "Hi! Hope you're well. Could you confirm whether the workshop is still on for Thursday at 2pm, and can I bring a colleague? Also, is there parking? Thanks, Sam" — yes still on, colleague welcome, parking is the free lot on Pine St.
```

Must contain: starts 'Sam —'; Thursday 2pm confirmed; colleague welcome; free lot on Pine St; 'Thanks,' then 'N.'; no 'hope this email finds you well'

## client-proposal

```
client: Harbor Bakery (owner Lucia). wants online preorders for holiday cakes so phone stops ringing. we'd do: simple order form, menu page with 6 cakes, email confirmations, staff guide. 3 weeks. price 1,800 dollars. next step: 20-min call friday
```

Must contain: goal in client's words (preorders, phone); 4 deliverables; timeline table ~3 weeks; price 1,800 exactly; next step: call Friday

## executive-summary

```
Q3 report — Northwind Coffee. Revenue was 412,000 dollars, up 9% on Q2. Online orders grew to 31% of sales from 22%. Cafe foot traffic fell 4% after the Elm St roadworks began in August; the roadworks end in November. Cost of beans rose 12% and margin slipped from 61% to 57%. Subscription box launched in July and reached 1,140 subscribers with 6% monthly churn. The team proposes a price increase of 0.30 per drink in Q4 and moving 2 staff hours a day from the Elm St cafe to online packing.
```

Must contain: bottom line sentence; 5 bullets; 412,000 / 9%; 31% from 22%; margin 61% -> 57%; 1,140 subscribers / 6% churn; risk to watch

## spreadsheet-snapshot

```
month,orders,revenue
Jan,120,3600
Feb,135,4050
Mar,128,3840
Apr,160,4800
May,171,5130
Jun,190,5700
```

Must contain: 6 rows, 3 columns; orders total 904; revenue total 27,120; top Jun 5,700 / bottom Jan 3,600; rising trend; one recommendation

## weekly-status

```
week of oct 6. shipped the pricing page. onboarding emails 70% done. blocked on stripe tax setup - need finance (Ava) to confirm the tax ID. next week: finish onboarding emails, launch referral test, hire interview tues
```

Must contain: Week of Oct 6; Done: pricing page; In progress: onboarding emails 70%; Blocked: Stripe tax, Ava, tax ID; Next week: 3 items; <= 120 words

## study-flashcards

```
Photosynthesis happens in the chloroplasts of plant cells. It uses light energy, water and carbon dioxide to make glucose and oxygen. The light-dependent reactions happen in the thylakoid membranes and produce ATP and NADPH. The Calvin cycle happens in the stroma and uses ATP and NADPH to fix carbon dioxide into sugar. The main pigment is chlorophyll, which absorbs mostly blue and red light and reflects green. The overall equation is 6CO2 + 6H2O + light -> C6H12O6 + 6O2.
```

Must contain: 8 flashcards table; chloroplast; thylakoid / ATP+NADPH; Calvin cycle in stroma; chlorophyll reflects green; equation; 3 MCQs with answers at the end

## brainstorm-ten

```
Ideas to get more customers for a small dog-grooming shop in a college town
```

Must contain: exactly 10 numbered ideas; bold names; top 3 ranked; first step under 30 min

## sop-writer

```
how we onboard a new client: when they sign, Jess sends the welcome email from Gmail with the intake form link (Google Forms). when the form comes back I set up their folder in Google Drive and copy the template. then we book the kickoff call in Calendly. people forget to share the folder with the client so check that. done when the kickoff is booked and folder shared
```

Must contain: SOP title + purpose; Owner + Tools (Gmail, Google Forms, Google Drive, Calendly); numbered verb-first steps in order; Check: share folder; Done when: kickoff booked + folder shared

## content-repurposer

```
We tested 3 AI note-takers on 20 real meetings. Otter caught 92% of action items, Fireflies 88%, and a plain Gemini summary 81%. The biggest misses were dates said out loud. Our takeaway: whichever tool you use, read the action items back at the end of the meeting.
```

Must contain: LinkedIn post with hook + question + 3 hashtags at end; X post < 270 chars no hashtags; newsletter blurb + Read more; 92 / 88 / 81 exact
