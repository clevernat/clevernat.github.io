# Gemini + Claude skills pack (AI Walkthru)

10 tested skills as SKILL.md files. Each folder holds one skill.

**Gemini:** gemini.google.com > menu > Skills > upload icon > files > pick a folder's SKILL.md > Create.
Needs a personal Google account, 18+, Keep Activity on. Use one with `/` + its name, or just ask and let Gemini pick it.

**Claude:** claude.ai > Customize > Skills > Add > Upload skill > pick the same SKILL.md > Upload.

Edit any skill to fit you: the description says WHEN to use it, the instructions say HOW.
TEST-NOTES.md has the exact notes used in the video and what a correct answer must contain.
