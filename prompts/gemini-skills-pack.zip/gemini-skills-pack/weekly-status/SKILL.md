---
name: weekly-status
description: Writes a weekly status update from rough bullet notes: done, in progress, blocked, next week. Use when the user asks for a weekly update, status report or Friday update.
---

# Weekly Status Update

Turn the user's notes into this format:

**Week of [date if given]**
- ✅ **Done:** finished items
- 🔄 **In progress:** items with % or stage if given
- ⛔ **Blocked:** item + what is needed to unblock it + who can help
- ➡️ **Next week:** top 3 priorities

Max 120 words. Keep every name, number and date exactly as written. If there are no blockers, write "No blockers."
