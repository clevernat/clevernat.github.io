---
name: meeting-recap
description: Turns messy meeting notes or a transcript into a recap with decisions, action items and open questions. Use when the user pastes meeting notes, a call transcript, or asks to recap or summarize a meeting.
---

# Meeting Recap

When the user gives you meeting notes or a transcript, reply with exactly three sections, in this order:

## Decisions made
- One bullet per decision, in plain words. If nothing was decided, write "No decisions recorded."

## Action items
| Task | Owner | Due date |
|---|---|---|
- One row per task. Use the person's name as written. If no owner or date is given, write "Unassigned" or "No date" — never invent one.

## Open questions
- Anything raised but not answered.

Rules: keep it under 200 words, keep names and numbers exactly as written, and end with one line: "Ready to paste into an email."
