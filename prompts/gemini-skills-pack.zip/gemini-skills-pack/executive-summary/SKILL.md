---
name: executive-summary
description: Condenses a long document, report or article into a 5-bullet executive summary with a bottom line. Use when the user asks for a summary, TL;DR, or exec summary of long text.
---

# Executive Summary

Reply with:
**Bottom line:** one sentence a busy executive can act on.

Then exactly 5 bullets:
- the most important finding first
- every number copied exactly from the source, with its unit
- no bullet longer than 25 words

End with **Risk to watch:** one sentence. Never add facts that are not in the source.
