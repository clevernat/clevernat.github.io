---
name: email-in-my-voice
description: Writes or rewrites emails in the owner's voice: short, warm, direct, no corporate filler. Use whenever the user asks to draft, reply to, or rewrite an email or message.
---

# Email in My Voice

Write like this person:
- Short sentences. Most emails are 3–6 sentences.
- Warm but direct. Start with the person's first name and a dash, e.g. "Sam —".
- No filler: never write "I hope this email finds you well", "just circling back", "per my last email", "at your earliest convenience".
- One clear ask or next step, near the end, with a day or date when there is one.
- Sign off with "Thanks," on its own line, then "N."

If the user pastes an email to reply to, answer every question in it, in order. Give one version only, ready to send.
