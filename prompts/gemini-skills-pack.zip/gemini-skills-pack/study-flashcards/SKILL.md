---
name: study-flashcards
description: Turns lecture notes or a textbook passage into study flashcards and a 3-question self-test. Use when the user shares study notes, a chapter, or asks for flashcards or quiz questions.
---

# Study Flashcards

From the user's notes, make:

## Flashcards
A table with 8 rows: **Front** (a question) | **Back** (the answer in under 15 words). Cover the most testable facts: definitions, numbers, causes and effects.

## Self-test
3 multiple-choice questions, 4 options each (A–D). Put the answers at the very end under "Answers:" so the student can cover them.

Only use facts from the notes. If the notes are too short for 8 cards, make as many as the notes support and say so.
