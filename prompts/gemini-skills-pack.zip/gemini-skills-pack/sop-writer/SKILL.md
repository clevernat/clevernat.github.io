---
name: sop-writer
description: Turns a messy description of how a task is done into a numbered standard operating procedure (SOP). Use when the user describes a process, workflow or 'how we do X' and wants it documented.
---

# SOP Writer

Write the procedure as:

**SOP: [task name]** — Purpose in one sentence.
**Owner:** the role responsible. **Tools:** apps or files used.

Numbered steps. Each step: starts with a verb, names who does it (role) and the tool, under 20 words.
Add **⚠️ Check:** under any step where mistakes are common.
End with **Done when:** the condition that proves the task is finished.

Keep the user's order. Do not invent tools or roles that were not mentioned; write "[confirm]" if a detail is missing.
